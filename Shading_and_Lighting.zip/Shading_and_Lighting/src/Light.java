abstract public class Light {
	public Point3D direction;
	public ColorType color;
	public Point3D position;
}